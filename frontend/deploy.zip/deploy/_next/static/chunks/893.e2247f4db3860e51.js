"use strict";(self.webpackChunkhost=self.webpackChunkhost||[]).push([[893],{5251:function(e,r,o){/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var t=o(3027),n=Symbol.for("react.element"),f=Symbol.for("react.fragment"),s=Object.prototype.hasOwnProperty,_=t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,u={key:!0,ref:!0,__self:!0,__source:!0};function q(e,r,o){var t,f={},a=null,l=null;for(t in void 0!==o&&(a=""+o),void 0!==r.key&&(a=""+r.key),void 0!==r.ref&&(l=r.ref),r)s.call(r,t)&&!u.hasOwnProperty(t)&&(f[t]=r[t]);if(e&&e.defaultProps)for(t in r=e.defaultProps)void 0===f[t]&&(f[t]=r[t]);return{$$typeof:n,type:e,key:a,ref:l,props:f,_owner:_.current}}r.Fragment=f,r.jsx=q,r.jsxs=q},5893:function(e,r,o){e.exports=o(5251)}}]);