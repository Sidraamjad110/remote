"use strict";(self.webpackChunkremoteApp=self.webpackChunkremoteApp||[]).push([[848],{1020:function(e,r,o){/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var t=o(379),n=Symbol.for("react.element"),f=Symbol.for("react.fragment"),p=Object.prototype.hasOwnProperty,s=t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,_={key:!0,ref:!0,__self:!0,__source:!0};function q(e,r,o){var t,f={},u=null,a=null;for(t in void 0!==o&&(u=""+o),void 0!==r.key&&(u=""+r.key),void 0!==r.ref&&(a=r.ref),r)p.call(r,t)&&!_.hasOwnProperty(t)&&(f[t]=r[t]);if(e&&e.defaultProps)for(t in r=e.defaultProps)void 0===f[t]&&(f[t]=r[t]);return{$$typeof:n,type:e,key:u,ref:a,props:f,_owner:s.current}}r.Fragment=f,r.jsx=q,r.jsxs=q},4848:function(e,r,o){e.exports=o(1020)}}]);